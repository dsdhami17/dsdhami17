//
//  Bookdetail.swift
//  Library Project
//
//  Created by veerlinux on 10/14/17.
//  Copyright © 2017 veerlinux. All rights reserved.
//

import Foundation

class Bookdetail{
    private var BookId:Int
    private var BookName:String
    private var BookCategory:String
    private var Bookpublisher:String
    private var Edition:String
    private var BookPrice:Double
    
    
    init(bookid:Int , bookname:String,Bcat:String , bookpub:String , edition:String, Bookprice:Double) {
        BookId = bookid
        BookName = bookname
        BookCategory = Bcat
        Bookpublisher = bookpub
        Edition = edition
        BookPrice = Bookprice
    }
    
    func getBookId() -> Int {
        return BookId
    }
    func getBname() -> String {
        return BookName
    }
    func getcategory() -> String {
        return BookCategory
    }
    func getpublisher() -> String {
        return Bookpublisher
    }
    func getedition() -> String {
        return Edition
    }
    func getbookprice() -> Double {
        
        return BookPrice
    }
    func setbookId(BId:Int)  {
        BookId = BId
    }
    func setbookname(bookname:String) {
        BookName = bookname
    }
    func setcategory(bookcate:String) {
        BookCategory = bookcate
    }
    func setpub(bookpublisher:String)  {
        Bookpublisher = bookpublisher
    }
    func setedition(edition:String) {
        Edition = edition
    }
    func setbookprice(bkPrice:Double) {
        BookPrice = bkPrice
    }
    
}
