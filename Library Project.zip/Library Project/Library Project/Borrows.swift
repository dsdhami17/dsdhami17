//
//  Borrows.swift
//  Library Project
//
//  Created by veerlinux on 10/14/17.
//  Copyright © 2017 veerlinux. All rights reserved.
//

import Foundation

class Borrows{
    public var BorrowId:Int
    public var MemberId:Memberdetail
    public var IssueDate:String
    public var ReturnDate:String
    public var DueDate:String
    public var BookId:Bookdetail
    
    init(borrowId:Int , memberId:Memberdetail , issuedate:String , returndate:String , duedate:String , bookid:Bookdetail) {
        BorrowId = borrowId
        MemberId = memberId
        IssueDate = issuedate
        ReturnDate = returndate
        DueDate = duedate
        BookId = bookid
        
    }
    
    func getborrowid() -> Int {
        return BorrowId
    }
    func getmemberid() -> Memberdetail {
        return MemberId
    }
    func getissuedate() -> String {
        return IssueDate
    }
    func getreturndate() -> String {
        return ReturnDate
    }
    func getduedate() -> String {
        return DueDate
    }
    func getbookid() -> Bookdetail {
        return BookId
        
    }
    func setborrowid(borrowid:Int)  {
        BorrowId = borrowid
    }
    func setmemberid(memberid:Memberdetail)  {
        MemberId = memberid
    }
    func setissuedate(issuedate:String) {
        IssueDate = issuedate
    }
    func setreturndate(returndate:String)  {
        ReturnDate = returndate
    }
    func setduedate(duedate:String) {
        DueDate = duedate
    }
    func setbookid(bookid:Bookdetail) {
        BookId = bookid
    }
}
