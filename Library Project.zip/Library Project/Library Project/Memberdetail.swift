//
//  Memberdetail.swift
//  Library Project
//
//  Created by veerlinux on 10/14/17.
//  Copyright © 2017 veerlinux. All rights reserved.
//

import Foundation

class Memberdetail{
    private var MemberId:Int
    private var MemberName:String
    private var City:String
    private var TotalFine:Int
    
    init(mId:Int,mName:String,city:String,tfine:Int) {
        
        MemberId = mId
        MemberName = mName
        City = city
        TotalFine = tfine

        
    }
    
    func getMid() -> Int {
        return MemberId
    }
    func getMname() -> String {
        return MemberName
    }
    func getcity() -> String {
        return City
    }
    func gettotalfine() -> Int {
        return TotalFine
    }
    
    func setMid(mId:Int) {
        MemberId = mId
    }
    func setmname(mname:String) {
        MemberName = mname
    }
    func setcity(citymember:String) {
        City = citymember
    }
    func settotalfine(tfine:Int){
        TotalFine = tfine
    }
    
}
