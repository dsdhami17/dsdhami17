//
//  Location.swift
//  Library Project
//
//  Created by veerlinux on 10/14/17.
//  Copyright © 2017 veerlinux. All rights reserved.
//

import Foundation

class Location{
    private var LocationId: Int
    private var ShelfId: Int
    private var RowNo:Int
    private var BookId:Bookdetail
    
    init(locId : Int, shfid : Int, rowno : Int , bookId : Bookdetail)
    {
        LocationId = locId
        ShelfId = shfid
        RowNo = rowno
        BookId = bookId
    }
    func getlocationid() -> Int {
        return LocationId
    }
    func getshelfid() -> Int {
        return ShelfId
    }
    func getrowno() ->Int {
        return RowNo
    }
    func getbookid() ->Bookdetail{
        return BookId
    }
    func setlocationid(locid:Int) {
        LocationId = locid
    }
    func setshelfid(shelfid:Int) {
        ShelfId = shelfid
    }
    func setrowno(rowno:Int) {
        RowNo = rowno
    }
}
