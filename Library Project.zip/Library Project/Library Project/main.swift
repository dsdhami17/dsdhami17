//
//  main.swift
//  Library Project
//
//  Created by veerlinux on 10/14/17.
//  Copyright © 2017 veerlinux. All rights reserved.
//

import Foundation




print("*****************************************************BOOK DETAIL**********************************************************************")

print("BookID\t\t\t\t\t BookName \t\t\t\t\t BookCategory\t\t\t\t\t BookPublisher \t\t\t\t\t Edition\t\t\t\t\t BookPrice \t\t")
print("**************************************************************************************************************************************")

var b1 = Bookdetail(bookid: 11, bookname: "MicroProcessor", Bcat: "Computers", bookpub: "laxmi publications", edition:"11/12/2011" , Bookprice: 250.25);
var b2 = Bookdetail(bookid: 12, bookname: "Software Testing", Bcat: "computer", bookpub: "anmol kaur", edition: "15/05/2013", Bookprice: 305.25);
var b3 = Bookdetail(bookid: 13, bookname: "mahabharat", Bcat: "Storyofpandavas", bookpub: "sonyTv", edition: "15/05/2014", Bookprice: 20.55);
var b4 = Bookdetail(bookid: 14, bookname: "Att Jatt", Bcat: "Jatt Crew", bookpub: "Desi Jatt", edition: "05/05/2016", Bookprice: 2000.0);
var b5 = Bookdetail(bookid: 15, bookname: "Lifestyle", Bcat: "Sidhu moosewala", bookpub: "AK47 wale", edition: "01/01/2017", Bookprice: 150.99);





print("\(b1.getBookId())\t\t\t\t\t\(b1.getBname())\t\t\t\t\t\(b1.getcategory())\t\t\t\t\t\(b1.getpublisher())\t\t\t\t\t\(b1.getedition())\t\t\t\t\t\(b1.getbookprice())")
print("\(b2.getBookId())\t\t\t\t\t\(b2.getBname())\t\t\t\t\t\(b2.getcategory())\t\t\t\t\t\(b2.getpublisher())\t\t\t\t\t\(b2.getedition())\t\t\t\t\t\(b2.getbookprice())")
print("\(b3.getBookId())\t\t\t\t\t\(b3.getBname())\t\t\t\t\t\(b3.getcategory())\t\t\t\t\t\(b3.getpublisher())\t\t\t\t\t\(b3.getedition())\t\t\t\t\t\(b3.getbookprice())")
print("\(b4.getBookId())\t\t\t\t\t\(b4.getBname())\t\t\t\t\t\(b4.getcategory())\t\t\t\t\t\(b4.getpublisher())\t\t\t\t\t\(b4.getedition())\t\t\t\t\t\(b4.getbookprice())")
print("\(b5.getBookId())\t\t\t\t\t\(b5.getBname())\t\t\t\t\t\(b5.getcategory())\t\t\t\t\t\(b5.getpublisher())\t\t\t\t\t\(b5.getedition())\t\t\t\t\t\(b5.getbookprice())")

print("")
print("****************************************************MEMBER DETAIL*********************************************************************")

print("memberId \t\t\t\t\t\t\t\t\t  MemberName \t\t\t\t\t\t\t\t\t City \t\t\t\t\t\t\t\t\t TotalFine \t\t\t\t\t\t\t\t\t BorrowId")
print("**************************************************************************************************************************************")

var m1 = Memberdetail(mId: 31, mName: "jatt singh", city: "brampton", tfine: 500)
var m2 = Memberdetail(mId: 32, mName: "jhalla singh", city: "brampton", tfine: 300)
var m3 = Memberdetail(mId: 33, mName: "siraa jatt", city: "brampton", tfine: 0)

print("\(m1.getMid())\t\t\t\t\t\t\t\t\t\(m1.getMname())\t\t\t\t\t\t\t\t\t\(m1.getcity())\t\t\t\t\t\t\t\t\t\(m1.gettotalfine())")
print("\(m2.getMid())\t\t\t\t\t\t\t\t\t\(m2.getMname())\t\t\t\t\t\t\t\t\t\(m2.getcity())\t\t\t\t\t\t\t\t\t\(m2.gettotalfine())")
print("\(m3.getMid())\t\t\t\t\t\t\t\t\t\(m3.getMname())\t\t\t\t\t\t\t\t\t\(m3.getcity())\t\t\t\t\t\t\t\t\t\(m3.gettotalfine())")
print("")
print("************************************************************Location****************************************")

var l1 = Location(locId: 55, shfid: 21, rowno: 2, bookId: b1)
var l2 = Location(locId: 66, shfid: 22, rowno:3, bookId: b2)
var l3 = Location(locId: 77, shfid: 23, rowno: 4, bookId: b3)


print("LocationId \t\t\t\t\t ShelfID \t\t\t\t\t Row No \t\t\t\t\t BookID")
print("************************************************************************************************************")

print("\(l1.getlocationid())\t\t\t\t\t\(l1.getshelfid())\t\t\t\t\t\(l1.getrowno())\t\t\t\t\t\(l1.getbookid())")
print("\(l3.getlocationid())\t\t\t\t\t\(l2.getshelfid())\t\t\t\t\t\(l3.getrowno())\t\t\t\t\t\(l2.getbookid())")
print("\(l3.getlocationid())\t\t\t\t\t\(l3.getshelfid())\t\t\t\t\t\(l3.getrowno())\t\t\t\t\t\(l3.getbookid())")
print("************************************************************************************************************")



print("****************************************BORROWS TABLE******************************************")

var br1 = Borrows(borrowId: 41, memberId: m1, issuedate: "12/2/2016", returndate: "16/2/2016", duedate: "14/2/2016", bookid: b1)
var br2 = Borrows(borrowId: 42, memberId: m2, issuedate: "13/2/2016", returndate: "17/2/2016", duedate: "15/2/2016", bookid: b2)
var br3 = Borrows(borrowId: 43, memberId: m2, issuedate: "14/2/2016", returndate: "18/2/2016", duedate: "16/2/2016", bookid: b3)

print("BorrowId \t\t\t MemberID \t\t\t Issuedate \t\t\t Returndate \t\t\t duedate \t\t\t bookId")
print("***********************************************************************************************")

print("\(br1.getborrowid())\t\t\t\(br1.getmemberid())\t\t\t\(br1.getissuedate())\t\t\t\(br1.getreturndate())\t\t\t\(br1.getduedate())\t\t\t\(br1.getbookid())")
print("\(br2.getborrowid())\t\t\t\(br2.getmemberid())\t\t\t\(br2.getissuedate())\t\t\t\(br2.getreturndate())\t\t\t\(br2.getduedate())\t\t\t\(br2.getbookid())")
print("\(br3.getborrowid())\t\t\t\(br3.getmemberid())\t\t\t\(br3.getissuedate())\t\t\t\(br3.getreturndate())\t\t\t\(br3.getduedate())\t\t\t\(br3.getbookid())")
print("***********************************************************************************************")

